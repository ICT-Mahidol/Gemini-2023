function submitTestForm() {
    const planId = document.getElementById('planId').value;
    const testType = document.getElementById('testType').value;
    const testDateStart = document.getElementById('testDateStart').value;
    const testDateEnd = document.getElementById('testDateEnd').value;

    const url = `/testSciencePlan/${planId}?type=${testType}&start=${testDateStart}&end=${testDateEnd}`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            window.location.href = 'results.html?results=' + encodeURIComponent(JSON.stringify(data));
        })
        .catch(error => console.error('Error testing science plan:', error));
}


