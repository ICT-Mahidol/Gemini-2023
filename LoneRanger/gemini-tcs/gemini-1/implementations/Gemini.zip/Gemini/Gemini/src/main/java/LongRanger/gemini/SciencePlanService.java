package LongRanger.gemini;

import edu.gemini.app.ocs.model.SciencePlan;

import java.util.List;

public interface SciencePlanService {

    LongRanger.gemini.SciencePlan getSciencePlanById(int planNo);

    List<SciencePlan> getAllSciencePlans();

    void saveSciencePlan(SciencePlan sciencePlan);

    String testSciencePlan(SciencePlan sciencePlan);
}


