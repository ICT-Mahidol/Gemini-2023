package LongRanger.gemini;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@SuppressWarnings("ALL")
@Controller
public class SciencePlanController {
    private final SciencePlanService sciencePlanService;
    private final SciencePlanTester sciencePlanTester;

    public SciencePlanController(SciencePlanService sciencePlanService, SciencePlanTester sciencePlanTester) {
        this.sciencePlanService = sciencePlanService;
        this.sciencePlanTester = sciencePlanTester;
    }

    @GetMapping("/testSciencePlan/{planNo}")
    public String testSciencePlan(@PathVariable int planNo, @RequestParam String type, @RequestParam String start, @RequestParam String end, Model model) {
        SciencePlan plan = sciencePlanService.getSciencePlanById(planNo);
        try {
            String results = sciencePlanTester.testSciencePlan(plan);
            model.addAttribute("testResults", results);
        } catch (Exception e) {
            model.addAttribute("testResults", "Test failed due to an error: " + e.getMessage());
        }
        return "testResults";
    }
}



