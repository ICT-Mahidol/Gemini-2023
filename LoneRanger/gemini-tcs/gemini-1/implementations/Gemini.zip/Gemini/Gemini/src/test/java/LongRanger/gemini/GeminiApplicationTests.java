package LongRanger.gemini;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeminiApplicationTests {

    @Test
    void contextLoads() {
    }

}
