package LongRanger.gemini;

import edu.gemini.app.ocs.model.SciencePlan;

import java.util.List;

public interface TestSciencePlanService {

    TestSciencePlan getSciencePlanById(int planNo);

    List<TestSciencePlan> getAllSciencePlans();

    void saveSciencePlan(TestSciencePlan sciencePlan);

    String testSciencePlan(TestSciencePlan sciencePlan);
}


