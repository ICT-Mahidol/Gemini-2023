package LongRanger.gemini;

import edu.gemini.app.ocs.model.*;
import edu.gemini.app.ocs.model.AstronomicalData;
import java.util.Date;
import java.io.IOException;

public class SciencePlanTester {

    public boolean testSelectedStarSystem(TestSciencePlan plan) {
        StarSystem.CONSTELLATIONS starSystem = plan.getStarSystem();
        return starSystem.equals(new Date());
    }

    public boolean testTelescopeLocation(TestSciencePlan plan) {
        return plan.getTelescopeLocation().equals(plan.getStarSystem());
    }

    public boolean testDuration(TestSciencePlan plan) {
        try {
            plan.getEndDate().wait();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return false;
    }

    public String testSciencePlan(TestSciencePlan plan) throws IOException {
        StringBuilder testResults = new StringBuilder();
        testResults.append("Testing Selected Star System: ").append(testSelectedStarSystem(plan) ? "PASSED" : "FAILED").append("\n");
        testResults.append("Testing Telescope Location: ").append(testTelescopeLocation(plan) ? "PASSED" : "FAILED").append("\n");
        testResults.append("Testing Duration: ").append(testDuration(plan) ? "PASSED" : "FAILED").append("\n");
        AstronomicalData astroData = plan.retrieveAstroData();
        testResults.append("Retrieved Astronomical Data: ").append(astroData != null ? "SUCCESS" : "FAILED").append("\n");
        return testResults.toString();
    }
}
