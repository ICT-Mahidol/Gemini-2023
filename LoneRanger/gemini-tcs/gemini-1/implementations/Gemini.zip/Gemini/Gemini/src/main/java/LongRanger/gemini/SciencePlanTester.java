package LongRanger.gemini;

import edu.gemini.app.ocs.model.*;
import edu.gemini.app.ocs.model.AstronomicalData;
import java.util.Date;
import java.io.IOException;

public class SciencePlanTester {

    public boolean testSelectedStarSystem(SciencePlan plan) {
        StarSystem.CONSTELLATIONS starSystem = plan.getStarSystem();
        return starSystem.isObservable(new Date());
    }

    public boolean testTelescopeLocation(SciencePlan plan) {
        return plan.getTelescopeLocation().equals(plan.getStarSystem().getTelescopeLoc());
    }

    public boolean testDuration(SciencePlan plan) {
        return plan.getStartDate().before(plan.getEndDate());
    }

    public String testSciencePlan(SciencePlan plan) throws IOException {
        StringBuilder testResults = new StringBuilder();
        testResults.append("Testing Selected Star System: ").append(testSelectedStarSystem(plan) ? "PASSED" : "FAILED").append("\n");
        testResults.append("Testing Telescope Location: ").append(testTelescopeLocation(plan) ? "PASSED" : "FAILED").append("\n");
        testResults.append("Testing Duration: ").append(testDuration(plan) ? "PASSED" : "FAILED").append("\n");
        AstronomicalData astroData = plan.retrieveAstroData();
        testResults.append("Retrieved Astronomical Data: ").append(astroData != null ? "SUCCESS" : "FAILED").append("\n");
        return testResults.toString();
    }
}
