package LongRanger.gemini;

import edu.gemini.app.ocs.model.SciencePlan;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SciencePlanServiceImpl implements SciencePlanService {
    @Override
    public LongRanger.gemini.SciencePlan getSciencePlanById(int planNo) {
        return null;
    }

    @Override
    public List<SciencePlan> getAllSciencePlans() {
        return null;
    }

    @Override
    public void saveSciencePlan(SciencePlan sciencePlan) {
    }

    @Override
    public String testSciencePlan(SciencePlan sciencePlan) {
        return null;
    }
}
