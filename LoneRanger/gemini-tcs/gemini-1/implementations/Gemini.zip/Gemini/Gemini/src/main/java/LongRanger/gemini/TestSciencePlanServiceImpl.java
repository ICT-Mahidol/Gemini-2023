package LongRanger.gemini;

import edu.gemini.app.ocs.model.SciencePlan;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TestSciencePlanServiceImpl implements TestSciencePlanService {
    @Override
    public TestSciencePlan getSciencePlanById(int planNo) {
        return null;
    }

    @Override
    public List<TestSciencePlan> getAllSciencePlans() {
        return null;
    }

    @Override
    public void saveSciencePlan(TestSciencePlan sciencePlan) {
    }

    @Override
    public String testSciencePlan(TestSciencePlan sciencePlan) {
        return null;
    }
}
