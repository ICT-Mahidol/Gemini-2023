package LongRanger.gemini;

import java.io.Serializable;
import java.util.Objects;

public class DataProquirement implements Serializable {
    private String fileType;
    private String fileQuality;
    private String colorType;
    private double contrast;
    private double brightness;
    private double saturation;
    private double highlights;
    private double exposure;
    private double shadows;
    private double whites;
    private double blacks;
    private double luminance;
    private double hue;

    public double getHue() {
        return this.hue;
    }

    public void setHue(double hue) {
        this.hue = hue;
    }

    public double getLuminance() {
        return this.luminance;
    }

    public void setLuminance(double luminance) {
        this.luminance = luminance;
    }

    public double getBlacks() {
        return this.blacks;
    }

    public void setBlacks(double blacks) {
        this.blacks = blacks;
    }

    public double getWhites() {
        return this.whites;
    }

    public void setWhites(double whites) {
        this.whites = whites;
    }

    public double getShadows() {
        return this.shadows;
    }

    public void setShadows(double shadows) {
        this.shadows = shadows;
    }

    public double getHighlights() {
        return this.highlights;
    }

    public void setHighlights(double highlights) {
        this.highlights = highlights;
    }

    public DataProquirement() {
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        } else if (o != null && this.getClass() == o.getClass()) {
            DataProquirement that = (DataProquirement)o;
            return Double.compare(that.contrast, this.contrast) == 0 && Double.compare(that.brightness, this.brightness) == 0 && Double.compare(that.saturation, this.saturation) == 0 && Double.compare(that.highlights, this.highlights) == 0 && Double.compare(that.exposure, this.exposure) == 0 && Double.compare(that.shadows, this.shadows) == 0 && Double.compare(that.whites, this.whites) == 0 && Double.compare(that.blacks, this.blacks) == 0 && Double.compare(that.luminance, this.luminance) == 0 && Double.compare(that.hue, this.hue) == 0 && this.fileType.equals(that.fileType) && this.fileQuality.equals(that.fileQuality) && this.colorType.equals(that.colorType);
        } else {
            return false;
        }
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.fileType, this.fileQuality, this.colorType, this.contrast, this.brightness, this.saturation, this.highlights, this.exposure, this.shadows, this.whites, this.blacks, this.luminance, this.hue});
    }

    public double getExposure() {
        return this.exposure;
    }

    public void setExposure(double exposure) {
        this.exposure = exposure;
    }

    public DataProquirement(String fileType, String fileQuality, String colorType, double contrast, double brightness, double saturation, double highlights, double exposure, double shadows, double whites, double blacks, double luminance, double hue) {
        this.fileType = fileType;
        this.fileQuality = fileQuality;
        this.colorType = colorType;
        this.contrast = contrast;
        this.brightness = brightness;
        this.saturation = saturation;
        this.highlights = highlights;
        this.exposure = exposure;
        this.shadows = shadows;
        this.whites = whites;
        this.blacks = blacks;
        this.luminance = luminance;
        this.hue = hue;
    }

    public String getFileType() {
        return this.fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getFileQuality() {
        return this.fileQuality;
    }

    public void setFileQuality(String fileQuality) {
        this.fileQuality = fileQuality;
    }

    public String getColorType() {
        return this.colorType;
    }

    public void setColorType(String colorType) {
        this.colorType = colorType;
    }

    public double getContrast() {
        return this.contrast;
    }

    public void setContrast(double contrast) {
        this.contrast = contrast;
    }

    public double getBrightness() {
        return this.brightness;
    }

    public void setBrightness(double brightness) {
        this.brightness = brightness;
    }

    public double getSaturation() {
        return this.saturation;
    }

    public void setSaturation(double saturation) {
        this.saturation = saturation;
    }

    public String toString() {
        return "DataProcRequirement{fileType=" + this.fileType + ", fileQuality=" + this.fileQuality + ", colorType=" + this.colorType + ", contrast=" + this.contrast + ", brightness=" + this.brightness + ", saturation=" + this.saturation + ", highlights=" + this.highlights + ", exposure=" + this.exposure + ", shadows=" + this.shadows + ", whites=" + this.whites + ", blacks=" + this.blacks + ", luminance=" + this.luminance + ", hue=" + this.hue + "}";
    }
}
