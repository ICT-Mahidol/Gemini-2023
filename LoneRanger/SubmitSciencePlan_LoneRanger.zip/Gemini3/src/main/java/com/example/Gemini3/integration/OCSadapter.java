package com.example.Gemini3.integration;

import com.example.Gemini3.model.SciencePlan;
public class OCSadapter {
    public void validateSciencePlan(SciencePlan plan) {
        // Call OCS.jar validation methods here
    }

}
